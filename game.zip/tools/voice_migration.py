import csv
import json
from difflib import SequenceMatcher

def similar(a, b):
    return SequenceMatcher(None, a, b).ratio()

# 파일 경로 (필요에 따라 수정)
catalog_path = "/Users/al02528308/Documents/Git/eb_renpy/game/voice_ex/voice_catalog.json"
csv_path = "/Users/al02528308/Documents/Git/eb_renpy/newData/voiceSheet.csv"
output_csv_path = "/Users/al02528308/Documents/Git/eb_renpy/newData/voiceSheet_updated.csv"

# voice_catalog.json 읽기 (각 항목에 "text"와 "file_name" 필드가 있다고 가정)
with open(catalog_path, "r", encoding="utf-8") as f:
    catalog = json.load(f)

# CSV 파일 읽기
with open(csv_path, newline="", encoding="utf-8") as csvfile:
    reader = csv.DictReader(csvfile)
    rows = list(reader)

# 각 CSV 행의 텍스트와 catalog 항목 비교 (유사도가 90% 이상이면 file_name 기록)
for row in rows:
    # 이미 voiceFileName이 채워진 경우 스킵
    if row.get("voiceFileName", "").strip():
        continue

    csv_text = row["text"].strip()
    for entry in catalog.values():
        entry_text = entry.get("text", "").strip()
        if csv_text and entry_text and similar(csv_text, entry_text) >= 0.8:
            row["voiceFileName"] = entry["file_name"]
            break

# 결과를 새로운 CSV 파일에 저장 (모든 필드를 큰따옴표로 묶음)
with open(output_csv_path, "w", encoding="utf-8") as csvfile:
    fieldnames = rows[0].keys()
    writer = csv.DictWriter(csvfile, fieldnames=fieldnames, quoting=csv.QUOTE_ALL)
    writer.writeheader()
    writer.writerows(rows)

print("CSV 파일 업데이트 완료:", output_csv_path)