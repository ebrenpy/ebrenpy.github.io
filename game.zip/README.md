Ember and Blade Narrative Prototype (Ren'Py)
