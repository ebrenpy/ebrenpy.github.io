
import parse_rpy_to_json


rpy_content = '''define dlg_pool_poc2_act10_ar_bb = {

    "condition": lambda: has_keyword(kw_cv_ar_poc2), 

    "dialogues": [

        {
            "label": "bk_ar_act10_baphomet_met_1",
            "trigger": "enter_main_hall",
            "condition": lambda: ctx_last_run_met_boss,
            "post_bk": [
                ("ar", "Back from your dance with the deer demon?"),
                ("fx", "He sure knows how to swing that hammer."),
            ],
        },
        {
            "label": "bk_ar_act10_no_opening_2",
            "trigger": "enter_main_hall",
            "condition": lambda: seen_label("bk_ar_act10_no_opening_1"),
            "post_bk": [
                ( "ar", "Your zeal is quite something." ),
                ( "fx", "It gets results." ),
                ( "ar", "I'm sure it does. How reassuring." ),            
            ],
        },
    ]
}

define dialogues_act2_opening = [
 
    #-------------------------------------------------------------------------------
    # 액트 1 엔딩 (trigger: "act_ending")
    {
        "label": "seq_act1_ending",
        "trigger": "act_ending",
        "priority": PRIORITY_CORE, 
        "condition": lambda: ctx_act == 1,
        "pre_bk": [
            ( "fx", "Whew, that was {i}not{/i} easy. Nothing on me, of course." ), 
                # 만만치 않은 녀석이었어. 물론 내가 더 강했지만.
            ( "ua", "(Footsteps)"),
                # (어디선가 발소리가 들린다)
            ( "lm", "Meow, meow! (Fenrix, I see someone approaching!)" ), 
                # 펜릭스, 누가 있다냥!
        ],
        "dialogue": [
            ( "ua", "At the angel's beck and call, I see, like a dog on a leash. Or a leash on a dog! Hunting the cervine demon." ), 
            ( "fx", "A-Ariella?" ), 
            ( "lm", "Meow...meow! (No, look closer! That's not my Ariella!!)" ), #아리엘라가 아니다냥! 자세히 보라냥!
            ( "ua", "(Laughter) Oh, Ariella, that pretty little fool. Sure, you can call me that if you want." ), 
            ( "fx", "Who are you? No... What are you?" ), 
            ( "ua", "For one thing, I'm not Ariella. But there is no Ariella without me. We share a sacred geometry, yes... I'm something like her shadow." ), 
            ( "fx", "Ariella's shadow? What's that supposed to mean? Quit with the riddles!" ), 
            ( "ua", "No need to rush. As long as you continue attempting this descent, you'll run into me eventually. Perhaps on the next floor..." ), 
        ],
        "post_bk": [
            ( "fx", "There's more going on here than I thought.\nI should go back and tell them about this." ), 
            ( "lm", "Meow... (I don't like this...)" ),
        ],
    },
    {
        "label": "cv_ar_act10_about_boss_1", 
        "trigger": "cv_ar",
        "priority": PRIORITY_CORE,      # 보스와 처음 만나는 건 중요 이벤트
        "condition": lambda: 
            ctx_last_run_met_boss and 
            not seen_label("cv_ar_poc2_post_baphomet_first_talk") and
            not seen_label("cv_ar_poc2_post_baphomet_no_opening"),      # 아리엘라와 처음 대화를 바포메트를 만난 후에 했으면 이 대화는 스킵
        "dialogue": [
            ( "ar", "So, the great demon hunter returns. How was your encounter with Baphomet?" ),
            ( "fx", "Let's just say we're...getting acquainted." ),
            ( "ar", "A social butterfly, I see. You'll be best friends with him before I know it." ), 
        ],
        "post_bk" : [
            ( "fx", "And here I thought she was warming up to me." ), 
        ]
    },
    {
        "label": "cv_ar_act10_about_boss_2", 
        "trigger": "cv_ar",
        "priority": PRIORITY_INFO, 
        "condition": lambda: ctx_last_run_met_boss,
        "dialogue": [
            ( "ar", "Can't get enough of Baphomet, hm? Couldn't bear to say goodbye to him?" ),
            ( "fx", "Alright. For all this talk, I'd like to see you try taking on that monstrosity." ),
            ( "ar", "I have. For decades. Now, if you're done with your social calls, there's work to be done." ),
        ],
        "post_bk": [
            ( "fx", "Well, that shut me up. No wonder she's so... charming." ),
        ]
    },
]

define dlg_pool_poc2_act10_bb = {

    "condition": lambda: not has_keyword(kw_cv_ar_poc2), 
    "dialogues": [

        #--------------------------------------------------------------------------------
        # 아리엘라를 무시하고 바포메트까지 만난 상황의 바크
        {
            "label": "bk_ar_act10_no_briefing_1",
            "trigger": "enter_main_hall",
            "condition": lambda: ctx_last_run_met_boss,
            "post_bk": [
                ( "ar", "Look who decided to grace us with his presence.\nHow thoughtful of you to ignore your host." ),
                ( "fx", "What do they say, manners maketh man?" ),
            ],
        },
    ]
}
'''

parsed_data = parse_rpy_to_json(rpy_content)