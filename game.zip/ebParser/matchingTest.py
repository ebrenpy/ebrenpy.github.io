import json
import os 
import regex as re

def all_d(rpy_content):
    data = []

    # 주석 제거
    rpy_content = re.sub(r'#(?!\S).*?\n', '', rpy_content)
    line_pattern = r'\(\s*"(.+?)"\s*,\s*"((?:[^"\\]|\\.)*?)".*\)'
    matches = re.findall(line_pattern, rpy_content)
    return matches
    
def all_dialogues(folder_path):
    all_data = []

    # 폴더 내 모든 .rpy 파일 처리
    for root, _, files in os.walk(folder_path):
        for file in files:
            if(file == "keywords.rpy"):
                continue
            if file.endswith('.rpy'):
                file_path = os.path.join(root, file)
                with open(file_path, 'r', encoding='utf-8') as rpy_file:
                    rpy_content = rpy_file.read()
                    lists = all_d(rpy_content)
                    all_data.extend(lists)
    
    with open("di.txt", 'w', encoding='utf-8') as file:
        file.writelines([f"{x[0]}: {x[1]}\n" for x in all_data])

def verify_dialoges(source_file):
        # 원하는 형식을 가진 객체를 찾기
    with open(source_file, 'r', encoding='utf-8') as file:
        data = json.load(file)
    matching_entries = []

    for dialgoueGroup in data:
        for dialgoue in dialgoueGroup.get("dialogues"):
            if "dialogue" in dialgoue:
                for line in dialgoue.get("dialogue"):
                        ch = line.get("character")
                        text = line.get("text").replace("\n", "\\n")
                        matching_entries.append(f"{ch}: {text}")
            if "pre_bk" in dialgoue:
                for line in dialgoue.get("pre_bk"):
                        ch = line.get("character")
                        text = line.get("text").replace("\n", "\\n")
                        matching_entries.append(f"{ch}: {text}")
            if "bk" in dialgoue:
                for line in dialgoue.get("bk"):
                        ch = line.get("character")
                        text = line.get("text").replace("\n", "\\n")
                        matching_entries.append(f"{ch}: {text}")
            if "post_bk" in dialgoue:
                for line in dialgoue.get("post_bk"):
                        ch = line.get("character")
                        text = line.get("text").replace("\n", "\\n")
                        matching_entries.append(f"{ch}: {text}")
                
    with open("di2.txt", 'w', encoding='utf-8') as file:
        file.writelines([f"{x}\n" for x in matching_entries])            

    
all_dialogues("./game/dialogues")
verify_dialoges("./dialogues.json")