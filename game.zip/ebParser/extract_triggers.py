import re
import json

def extract_triggers(file_content):
    # Regex pattern to match "trigger": "<value>"
    pattern = r'"trigger"\s*:\s*"(.*?)"'
    matches = re.findall(pattern, file_content)
    return list(set(matches))  # Remove duplicates

# Example usage
if __name__ == "__main__":
    # Read content from JSON file
    with open('dialogues.json', 'r', encoding='utf-8') as file:
        file_content = file.read()
    
    triggers = extract_triggers(file_content)
    
# Generate C# enum
    enum_definition = "public enum NarrativeTrigger\n{\n"
    for trigger in triggers:
        enum_definition += f"    {trigger},\n"
    enum_definition += "}"
    
    # Write enum to NarrativeTrigger.cs
    with open('NarrativeTrigger.cs', 'w', encoding='utf-8') as cs_file:
        cs_file.write(enum_definition)