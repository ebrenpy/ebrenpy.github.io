import re
import json

def extract_triggers(file_content):
    # Regex pattern to match "trigger": "<value>"
    pattern = r'"trigger"\s*:\s*"(.*?)"'
    matches = re.findall(pattern, file_content)
    return sorted(list(set(matches)))  # Remove duplicates and sort alphabetically

# Example usage
if __name__ == "__main__":
    # Read content from JSON file with UTF-8 encoding
    with open('dialogues.json', 'r', encoding='utf-8') as file:
        file_content = file.read()
    
    triggers = extract_triggers(file_content)
    
    # Generate C# enum with string values
    enum_definition = "public enum NarrativeTrigger\n{\n"
    for trigger in triggers:
        formatted_trigger = re.sub(r'[_\W]+', '', trigger.title().replace(" ", "")).replace("_", "")[0].lower() + re.sub(r'[_\W]+', '', trigger.title().replace(" ", "")).replace("_", "")[1:]  # Convert to camelCase
        enum_definition += f"    {formatted_trigger},\n"
    enum_definition += "}\n\n"

    # Generate C# dictionary to map enum to original string values
    dictionary_definition = "public static class NarrativeTriggerMapping\n{\n    public static readonly Dictionary<NarrativeTrigger, string> TriggerToString = new Dictionary<NarrativeTrigger, string>\n    {\n"
    for trigger in triggers:
        formatted_trigger = re.sub(r'[_\W]+', '', trigger.title().replace(" ", "")).replace("_", "")[0].lower() + re.sub(r'[_\W]+', '', trigger.title().replace(" ", "")).replace("_", "")[1:]  # Convert to camelCase
        dictionary_definition += f"        {{ NarrativeTrigger.{formatted_trigger}, \"{trigger}\" }},\n"
    dictionary_definition += "    };\n}\n"
    
    # Write enum and dictionary to NarrativeTrigger.cs
    with open('NarrativeTrigger.cs', 'w', encoding='utf-8') as cs_file:
        cs_file.write(enum_definition)
        cs_file.write(dictionary_definition)