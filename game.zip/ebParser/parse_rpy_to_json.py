import json
import re
import os
import ast

# PRIORITY 정의를 위한 매핑
PRIORITY_MAPPING = {
    "PRIORITY_CORE": 0,
    "PRIORITY_META": 1,
    "PRIORITY_INFO": 2,
    "PRIORITY_CASUAL": 3
}

def parse_condition(condition_str):
    """
    Parses the condition string into a logical expression tree.
    """
    # Preprocessing: Remove comments and unnecessary whitespace
    condition_str = re.sub(r'#.*', '', condition_str).strip()

    # Replace custom function calls with variable placeholders
    replacements = {
        "run_count()": "ctx_run_count",
        "total_run_count()": "ctx_run_count_total",
        "boss_meet_count()": "ctx_boss_meet_count",
        "boss_not_met()": "ctx_boss_meet_count == 0",
        "boss_not_met()": "ctx_boss_meet_count == 0",
        "seen_label": "seen_label_func",
        "has_keyword": "has_keyword_func",
        "\n" : "",
        '"' : "",
    }
    for old, new in replacements.items():
        condition_str = condition_str.replace(old, new)

    # Parse the condition string into an AST
    expr_ast = ast.parse(condition_str, mode='eval')

    def ast_to_dict(node):
        if isinstance(node, ast.BoolOp):
            op = 'and' if isinstance(node.op, ast.And) else 'or'
            return {
                'logicalOperator': op,
                'operands': [ast_to_dict(value) for value in node.values]
            }
        elif isinstance(node, ast.UnaryOp):
            if isinstance(node.op, ast.Not):
                return {
                    'unaryOperator': 'not',
                    'operand': ast_to_dict(node.operand)
                }
            else:
                return {
                    'unaryOperator': type(node.op).__name__,
                    'operand': ast_to_dict(node.operand)
                }
        elif isinstance(node, ast.Compare):
            left = ast_to_dict(node.left)
            comparator = ast_to_dict(node.comparators[0])
            operator = type(node.ops[0]).__name__
            operator_map = {
                'Eq': '==',
                'NotEq': '!=',
                'Lt': '<',
                'LtE': '<=',
                'Gt': '>',
                'GtE': '>='
            }
            return {
                'left': left,
                'comparisonOperator': operator_map.get(operator, operator),
                'right': comparator
            }
        elif isinstance(node, ast.Call):
            func_name = ast_to_dict(node.func)
            args = [ast_to_dict(arg) for arg in node.args]
            return {
                'function': func_name,
                'args': args
            }
        elif isinstance(node, ast.Name):
            return node.id
        elif isinstance(node, ast.Constant):
            return node.value
        elif isinstance(node, ast.Expr):
            return ast_to_dict(node.value)
        else:
            return ast.dump(node)

    condition_tree = ast_to_dict(expr_ast.body)

    return condition_tree

# 변환된 JSON 저장 함수
def save_as_json(data, output_file):
    with open(output_file, 'w', encoding='utf-8') as file:
        json.dump(data, file, indent=4, ensure_ascii=False)

def parse_blocks(block):
    data = []
    dialogue_data_list = re.findall(r'\{\s+(.*?)\}', block, re.DOTALL)
    for dialogue_block in dialogue_data_list:
        dialogue_data = {}
        
        # 라벨 추출
        label_match = re.search(r'"label"\s*:\s*"(.+?)"', dialogue_block)
        if label_match:
            dialogue_data['label'] = label_match.group(1)

        # 트리거 추출
        trigger_match = re.search(r'"trigger"\s*:\s*"(.+?)"', dialogue_block)
        if trigger_match:
            dialogue_data['trigger'] = trigger_match.group(1)

        # 우선순위 추출
        priority_match = re.search(r'"priority"\s*:\s*(\w+)', dialogue_block)
        if priority_match:
            priority_str = priority_match.group(1)
            dialogue_data['priority'] = PRIORITY_MAPPING.get(priority_str, "UNKNOWN")

        # 조건 추출 및 분리 (콤마가 나오기 전까지의 문자열을 모두 추출)
        condition_match = re.search(r'"condition"\s*:\s*lambda:\s*(.+?)(?=,\s*"|\})', dialogue_block, re.DOTALL)
        if condition_match:
            condition_str = condition_match.group(1).strip()
            dialogue_data['condition'] = parse_condition(condition_str)

        # 키워드 추출
        keyword_match = re.search(r'"keyword"\s*:\s*\[(.*?)\]', dialogue_block, re.DOTALL)
        if keyword_match:
            keywords = [kw.strip().replace('"', '') for kw in keyword_match.group(1).split(',') if kw.strip()]
            dialogue_data['keyword'] = keywords

        # 액티베이트 추출
        activate_match = re.search(r'"activate"\s*:\s*\[(.*?)\]', dialogue_block, re.DOTALL)
        if activate_match:
            activates = [ac.strip().replace('"', '') for ac in activate_match.group(1).split(',') if ac.strip()]
            dialogue_data['activate'] = activates

        # 디액티베이트 추출
        deactivate_match = re.search(r'"deactivate"\s*:\s*\[(.*?)\]', dialogue_block, re.DOTALL)
        if deactivate_match:
            deactivates = [da.strip().replace('"', '') for da in deactivate_match.group(1).split(',') if da.strip()]
            dialogue_data['deactivate'] = deactivates

        # 대화 추출 (줄바꿈 처리 포함)
        dialogue_lines = re.search(r'"dialogue"\s*:\s*\[(.*?)\]', dialogue_block, re.DOTALL)
        if dialogue_lines:
            dialogue_content = dialogue_lines.group(1).strip()
            dialogues = re.findall(r'\(\s*"(.+?)",\s*"((?:[^"\\]|\\.)*?)"\s*\)', dialogue_content)
            dialogue_data['dialogue'] = [{"character": char, "text": text.replace('\\n', '\n')} for char, text in dialogues]

        # 후속 대화 (post_bk 또는 bk) 추출 (줄바꿈 처리 포함)
        post_bk_lines = re.search(r'"post_bk"\s*:\s*\[(.*?)\]', dialogue_block, re.DOTALL)
        if post_bk_lines:
            post_bk_content = post_bk_lines.group(1).strip()
            post_dialogues = re.findall(r'\(\s*"(.+?)",\s*"((?:[^"\\]|\\.)*?)"\s*\)', post_bk_content)
            dialogue_data['post_bk'] = [{"character": char, "text": text.replace('\\n', '\n')} for char, text in post_dialogues]

        pre_bk_lines = re.search(r'"pre_bk"\s*:\s*\[(.*?)\]', dialogue_block, re.DOTALL)
        if pre_bk_lines:
            pre_bk_content = pre_bk_lines.group(1).strip()
            pre_bk_dialogues = re.findall(r'\(\s*"(.+?)",\s*"((?:[^"\\]|\\.)*?)"\s*\)', pre_bk_content)
            dialogue_data['pre_bk'] = [{"character": char, "text": text.replace('\\n', '\n')} for char, text in pre_bk_dialogues]


        bk_lines = re.search(r'"bk"\s*:\s*\[(.*?)\]', dialogue_block, re.DOTALL)
        if bk_lines:
            bk_content = bk_lines.group(1).strip()
            bk_dialogues = re.findall(r'\(\s*"(.+?)",\s*"((?:[^"\\]|\\.)*?)"\s*\)', bk_content)
            dialogue_data['bk'] = [{"character": char, "text": text.replace('\\n', '\n')} for char, text in bk_dialogues]

        # 필요한 데이터가 있는 경우 추가
        if dialogue_data:
            data.append(dialogue_data)
    return data

def parse_rpy_to_json(rpy_content):
    data = []

    # 주석 제거
    rpy_content = re.sub(r'#.*?\n', '', rpy_content)

    # 스타일링 rich text로 변경
    
    rpy_content = rpy_content.replace("{{i}}", "<i>").replace("{{/i}}", "</i>").replace("{{b}}", "<b>").replace("{{/b}}", "</b>")

    # 정규 표현식을 사용해 각 대화 블록을 분리
    blocks = re.split(r'\s*define\s+(\w+)\s*=\s*', rpy_content)

    dialogues_data = {}
    for block in blocks:
        if block == "":
            continue
        if block.startswith("{"):
            condition_match = re.search(r'\n\s{4}"condition":\s*lambda:\s*(.+?)(?=,\s*"|\})', block, re.DOTALL)
            if condition_match:
                condition_str = condition_match.group(1).strip()
                dialogues_data['condition'] = parse_condition(condition_str)
            
            dialogues_blocks = re.search(r'\n\s{4}"dialogues"\s*:\s*\[\s*(.*)', block, re.DOTALL)
            if dialogues_blocks == None :
                print("Invalid Dialogues Block "+block)
                continue

            dialogues_data['dialogues'] = parse_blocks(dialogues_blocks.group(1))
            data.append(dialogues_data)

        elif block.startswith("["):
            dialogues_blocks = re.search(r'\s*\[\s*(.*)', block, re.DOTALL)
            if dialogues_blocks == None :
                print("Invalid Dialogues Block "+block)
                continue

            dialogues_data['dialogues'] = parse_blocks(dialogues_blocks.group(1))
            data.append(dialogues_data)
        else : 
            dialogues_data = {}
            dialogues_data['name'] = block

    return data


def parse_rpy_folder_to_json(folder_path, output_file):
    all_data = []

    # 폴더 내 모든 .rpy 파일 처리
    for root, _, files in os.walk(folder_path):
        for file in files:
            if(file == "keywords.rpy"):
                continue
            if file.endswith('.rpy'):
                file_path = os.path.join(root, file)
                with open(file_path, 'r', encoding='utf-8') as rpy_file:
                    rpy_content = rpy_file.read()
                    parsed_data = parse_rpy_to_json(rpy_content)
                    all_data.extend(parsed_data)

    # 결과를 JSON으로 저장
    save_as_json(all_data, output_file)

parse_rpy_folder_to_json("./game/dialogues", "dialogues.json")