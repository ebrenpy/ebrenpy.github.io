import json
import yaml
import os

PRIORITY_MAP = {
    0: "PRIORITY_PROGRESS",
    1: "PRIORITY_CORE",
    2: "PRIORITY_META",
    3: "PRIORITY_INFO",
    4: "PRIORITY_CASUAL"
}

def get_priority(p):
    return PRIORITY_MAP.get(p, "PRIORITY_CASUAL")
    
def custom_sort(item):
    keys = item.keys()

    # 사용자 정의 정렬 순서
    sort_order = ['name', 'tag', 'label', 'trigger','bk_trigger', 'priority', 'condition', 'dialogues', 'barks', 'keyword', 'activate', 'deactivate', 'pre_bk','dialogue', 'post_bk', 'bk_var', 'set_cv', 'suppress_cv', 'bk' ]
    sort_order.extend([key for key in keys if key not in sort_order])

    return {key: item[key] for key in sort_order if key in item}

def json_to_yaml(json_file_path, output_dir):
    # JSON 파일 읽기
    with open(json_file_path, 'r', encoding='utf-8') as json_file:
        data = json.load(json_file)
    
    # 출력 디렉토리 생성
    os.makedirs(output_dir, exist_ok=True)
    
    file_count = 0
    dialogue_count = 0
    # 각 항목을 name 또는 label로 분리하여 YAML 파일로 저장
    for item in data:
        file_name = item.get('name')
        tag = item.get('label')
        if tag:
            item['tag'] = tag
            item.pop('label')

        dialogues = item.get('dialogues')
        newBkVars = []
        if dialogues:
            dialogue_count += len(dialogues)

        for dialgoue in dialogues: 
            priority = dialgoue.get('priority')
            if priority:
                dialgoue['priority'] = get_priority(priority)

            hasBk = False
            bkVar = dialgoue.get('bk_var')
            if bkVar :
                newBkVar = []
                for bk in bkVar:
                    newBkVar.append({'bk': bk})
                dialgoue['bk_var'] = newBkVar
                hasBk = True
            bk = dialgoue.get('bk')
            if bk and hasBk:
                print("???")
            elif bk:
                dialgoue['bk_var'] = [{'bk': bk}]
                dialgoue.pop('bk')
                hasBk = True
            
            if hasBk:
                trigger = dialgoue.get('trigger')
                dialgoue.pop('trigger')
                dialgoue['bk_trigger'] = trigger
                newBkVars.append(dialgoue)
                

            

        dialogues = [ custom_sort(dlg) for dlg in dialogues if not dlg.get('bk_var') ]
        item['dialogues'] = dialogues
        if len(newBkVars) > 0:
            item['barks'] = [custom_sort(dlg) for dlg in newBkVars]

        if file_name:
            sorted_item = custom_sort(item)
            yaml_file_path = os.path.join(output_dir, f"{file_name}.yaml")
            with open(yaml_file_path, 'w', encoding='utf-8') as yaml_file:
                yaml.dump(sorted_item, yaml_file, width=10000, allow_unicode=True, default_flow_style=False, sort_keys=False, indent=2)
            print(f"Saved {yaml_file_path}")
            file_count += 1

    print(f"총 {file_count}개의 파일(총 {dialogue_count}개의 대화)이 생성되었습니다.")

# JSON 파일 경로
json_file_path = '/Users/al02528308/Documents/Git/eb_renpy/meow/dialogues.json'
# 변환된 YAML 파일 경로
output_dir = '/Users/al02528308/Documents/Git/eb_renpy/meow/yaml_output'

# JSON 파일을 YAML 파일로 변환
json_to_yaml(json_file_path, output_dir)

print("JSON 파일이 YAML 파일로 변환되어 분리 저장되었습니다.")